"""
MarketPulse — Борсов монитор
Flask backend, данни от yfinance
"""

from flask import Flask, render_template, jsonify, request
import yfinance as yf
import json
import os
from datetime import datetime, timedelta
import pandas as pd

app = Flask(__name__)

# ── Файлове за персистентност ──────────────────────────────────────────────
TICKERS_FILE = "tickers.json"
PORTFOLIO_FILE = "portfolio.json"

# ── Начален списък тикери ──────────────────────────────────────────────────
DEFAULT_TICKERS = {
    "US": [
        # Технологии
        {"symbol": "AAPL",  "name": "Apple Inc."},
        {"symbol": "MSFT",  "name": "Microsoft"},
        {"symbol": "GOOGL", "name": "Alphabet"},
        {"symbol": "NVDA",  "name": "NVIDIA"},
        {"symbol": "META",  "name": "Meta Platforms"},
        {"symbol": "TSLA",  "name": "Tesla"},
        {"symbol": "AVGO",  "name": "Broadcom"},
        {"symbol": "AMD",   "name": "AMD"},
        # Банки и финанси
        {"symbol": "JPM",   "name": "JPMorgan Chase"},
        {"symbol": "BAC",   "name": "Bank of America"},
        {"symbol": "GS",    "name": "Goldman Sachs"},
        {"symbol": "V",     "name": "Visa"},
        {"symbol": "BRK-B", "name": "Berkshire Hathaway"},
        # Здравеопазване
        {"symbol": "JNJ",   "name": "Johnson & Johnson"},
        {"symbol": "UNH",   "name": "UnitedHealth"},
        {"symbol": "LLY",   "name": "Eli Lilly"},
        # Енергетика
        {"symbol": "XOM",   "name": "ExxonMobil"},
        {"symbol": "CVX",   "name": "Chevron"},
        # Потребителски стоки
        {"symbol": "KO",    "name": "Coca-Cola"},
        {"symbol": "PG",    "name": "Procter & Gamble"},
        {"symbol": "AMZN",  "name": "Amazon"},
        {"symbol": "WMT",   "name": "Walmart"},
        # ETF-и
        {"symbol": "SPY",   "name": "SPDR S&P 500 ETF"},
        {"symbol": "QQQ",   "name": "Invesco NASDAQ 100 ETF"},
        {"symbol": "DIA",   "name": "SPDR Dow Jones ETF"},
        {"symbol": "IWM",   "name": "iShares Russell 2000 ETF"},
    ],
    "DE": [
        # DAX компании
        {"symbol": "SAP.DE",  "name": "SAP SE"},
        {"symbol": "SIE.DE",  "name": "Siemens AG"},
        {"symbol": "ALV.DE",  "name": "Allianz SE"},
        {"symbol": "DTE.DE",  "name": "Deutsche Telekom"},
        {"symbol": "MUV2.DE", "name": "Munich Re"},
        {"symbol": "BMW.DE",  "name": "BMW AG"},
        {"symbol": "MBG.DE",  "name": "Mercedes-Benz"},
        {"symbol": "VOW3.DE", "name": "Volkswagen"},
        {"symbol": "BAYN.DE", "name": "Bayer AG"},
        {"symbol": "BASF.DE", "name": "BASF SE"},
        {"symbol": "DBK.DE",  "name": "Deutsche Bank"},
        {"symbol": "ADS.DE",  "name": "Adidas AG"},
        {"symbol": "LIN.DE",  "name": "Linde plc"},
        {"symbol": "AIR.DE",  "name": "Airbus (XETRA)"},
    ],
    "UK": [
        # FTSE 100
        {"symbol": "HSBA.L",  "name": "HSBC Holdings"},
        {"symbol": "BP.L",    "name": "BP plc"},
        {"symbol": "SHEL.L",  "name": "Shell plc"},
        {"symbol": "GSK.L",   "name": "GSK plc"},
        {"symbol": "AZN.L",   "name": "AstraZeneca"},
        {"symbol": "ULVR.L",  "name": "Unilever"},
        {"symbol": "RIO.L",   "name": "Rio Tinto"},
        {"symbol": "AAL.L",   "name": "Anglo American"},
        {"symbol": "LLOY.L",  "name": "Lloyds Banking"},
        {"symbol": "BARC.L",  "name": "Barclays"},
        {"symbol": "VOD.L",   "name": "Vodafone"},
        {"symbol": "REL.L",   "name": "RELX Group"},
        {"symbol": "DGE.L",   "name": "Diageo"},
    ],
    "EU": [
        # CAC 40 / Euronext
        {"symbol": "AIR.PA",  "name": "Airbus SE"},
        {"symbol": "MC.PA",   "name": "LVMH"},
        {"symbol": "OR.PA",   "name": "L'Oréal"},
        {"symbol": "SAN.PA",  "name": "Sanofi"},
        {"symbol": "BNP.PA",  "name": "BNP Paribas"},
        {"symbol": "TTE.PA",  "name": "TotalEnergies"},
        {"symbol": "SU.PA",   "name": "Schneider Electric"},
        {"symbol": "RI.PA",   "name": "Pernod Ricard"},
        # AEX (Amsterdam)
        {"symbol": "ASML.AS", "name": "ASML Holding"},
        {"symbol": "HEIA.AS", "name": "Heineken"},
        {"symbol": "PHIA.AS", "name": "Philips"},
        {"symbol": "WKL.AS",  "name": "Wolters Kluwer"},
        # ETF-и европейски
        {"symbol": "VUSA.AS", "name": "Vanguard S&P500 ETF"},
        {"symbol": "IWDA.AS", "name": "iShares World ETF"},
        {"symbol": "CSPX.L",  "name": "iShares S&P500 (LSE)"},
    ]
}

def load_tickers():
    if os.path.exists(TICKERS_FILE):
        with open(TICKERS_FILE) as f:
            return json.load(f)
    save_tickers(DEFAULT_TICKERS)
    return DEFAULT_TICKERS

def save_tickers(data):
    with open(TICKERS_FILE, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def load_portfolio():
    if os.path.exists(PORTFOLIO_FILE):
        with open(PORTFOLIO_FILE) as f:
            return json.load(f)
    return {}

def save_portfolio(data):
    with open(PORTFOLIO_FILE, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def get_all_symbols():
    tickers = load_tickers()
    symbols = []
    for market, items in tickers.items():
        for item in items:
            symbols.append({"symbol": item["symbol"], "name": item["name"], "market": market})
    return symbols

# ── Маршрути ───────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/quotes")
def get_quotes():
    """Връща текущи цени за всички тикери."""
    all_items = get_all_symbols()
    symbols = [item["symbol"] for item in all_items]
    name_map = {item["symbol"]: item["name"] for item in all_items}
    market_map = {item["symbol"]: item["market"] for item in all_items}

    try:
        data = yf.download(symbols, period="7d", interval="1d",
                           group_by="ticker", auto_adjust=True, progress=False, threads=True)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    results = []
    for sym in symbols:
        try:
            if len(symbols) == 1:
                df = data
            else:
                df = data[sym] if sym in data.columns.get_level_values(0) else pd.DataFrame()

            if df.empty or len(df) < 1:
                continue

            df = df.dropna()
            if len(df) < 1:
                continue

            latest = df.iloc[-1]
            prev    = df.iloc[-2] if len(df) > 1 else df.iloc[-1]
            week_start = df.iloc[0]  # первата сесия в 7-дневния прозорец

            price       = float(latest["Close"])
            prev_close  = float(prev["Close"])
            week_open   = float(week_start["Close"])
            change_pct  = ((price - prev_close) / prev_close * 100) if prev_close else 0
            change_abs  = price - prev_close
            week_pct    = ((price - week_open) / week_open * 100) if week_open else 0
            volume      = int(latest["Volume"]) if "Volume" in latest else 0

            # Допълнителна info (дивидент, market cap) — от fast_info
            try:
                t = yf.Ticker(sym)
                fi = t.fast_info
                market_cap  = getattr(fi, "market_cap", None)
                currency    = getattr(fi, "currency", "USD")
                div_yield   = None
                try:
                    info = t.info
                    div_yield = info.get("dividendYield")
                    if div_yield:
                        div_yield = round(div_yield * 100, 2)
                except:
                    pass
            except:
                market_cap = None
                currency   = "USD"
                div_yield  = None

            results.append({
                "symbol":     sym,
                "name":       name_map.get(sym, sym),
                "market":     market_map.get(sym, "US"),
                "price":      round(price, 2),
                "prev_close": round(prev_close, 2),
                "change_pct": round(change_pct, 2),
                "change_abs": round(change_abs, 2),
                "week_pct":   round(week_pct, 2),
                "volume":     volume,
                "market_cap": market_cap,
                "div_yield":  div_yield,
                "currency":   currency,
                "updated":    datetime.now().strftime("%H:%M:%S"),
            })
        except Exception:
            continue

    return jsonify(results)


@app.route("/api/sparkline/<symbol>")
def get_sparkline(symbol):
    """Връща 30-дневни затварящи цени за mini-chart."""
    try:
        df = yf.download(symbol, period="30d", interval="1d",
                         auto_adjust=True, progress=False)
        df = df.dropna()
        prices = [round(float(x), 2) for x in df["Close"].tolist()]
        return jsonify({"symbol": symbol, "prices": prices})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/dividends")
def get_dividends():
    """Връща ex-dividend дати за следващите 90 дни."""
    all_items = get_all_symbols()
    today = datetime.today().date()
    horizon = today + timedelta(days=90)
    events = []

    for item in all_items:
        sym = item["symbol"]
        try:
            t = yf.Ticker(sym)
            cal = t.calendar
            # calendar може да е dict или DataFrame в различни версии
            if isinstance(cal, dict):
                ex_date = cal.get("Ex-Dividend Date")
                div_amt = None
                try:
                    info = t.info
                    div_amt = info.get("lastDividendValue")
                except:
                    pass
            elif hasattr(cal, "T"):
                cal_t = cal.T
                ex_date = cal_t.get("Ex-Dividend Date", {}).get(0) if "Ex-Dividend Date" in cal_t else None
                div_amt = None
            else:
                ex_date = None
                div_amt = None

            if ex_date is None:
                # Fallback: последен дивидент от history
                div_hist = t.dividends
                if not div_hist.empty:
                    last_date = div_hist.index[-1].date()
                    last_amt  = float(div_hist.iloc[-1])
                    # Опит за следваща дата (грубо)
                    events.append({
                        "symbol":  sym,
                        "name":    item["name"],
                        "market":  item["market"],
                        "ex_date": str(last_date),
                        "amount":  round(last_amt, 4),
                        "future":  False,
                    })
                continue

            if hasattr(ex_date, "date"):
                ex_date = ex_date.date()
            elif isinstance(ex_date, str):
                ex_date = datetime.strptime(ex_date, "%Y-%m-%d").date()

            events.append({
                "symbol":  sym,
                "name":    item["name"],
                "market":  item["market"],
                "ex_date": str(ex_date),
                "amount":  round(div_amt, 4) if div_amt else None,
                "future":  today <= ex_date <= horizon,
            })
        except Exception:
            continue

    events.sort(key=lambda x: x["ex_date"])
    return jsonify(events)


@app.route("/api/tickers", methods=["GET"])
def get_tickers():
    return jsonify(load_tickers())

@app.route("/api/tickers", methods=["POST"])
def update_tickers():
    data = request.json
    save_tickers(data)
    return jsonify({"ok": True})

@app.route("/api/tickers/add", methods=["POST"])
def add_ticker():
    body   = request.json
    symbol = body.get("symbol", "").upper().strip()
    market = body.get("market", "US")
    name   = body.get("name", symbol)

    if not symbol:
        return jsonify({"error": "Липсва символ"}), 400

    # Проверка дали тикерът съществува
    try:
        t  = yf.Ticker(symbol)
        fi = t.fast_info
        _ = fi.last_price  # ще хвърли грешка ако не съществува
    except Exception:
        pass  # позволяваме добавяне дори без потвърждение

    tickers = load_tickers()
    if market not in tickers:
        tickers[market] = []

    # Проверка за дублиране
    existing = [x["symbol"] for x in tickers[market]]
    if symbol in existing:
        return jsonify({"error": "Тикерът вече съществува"}), 409

    tickers[market].append({"symbol": symbol, "name": name})
    save_tickers(tickers)
    return jsonify({"ok": True})

@app.route("/api/tickers/remove", methods=["POST"])
def remove_ticker():
    body   = request.json
    symbol = body.get("symbol", "").upper().strip()
    tickers = load_tickers()
    for market in tickers:
        tickers[market] = [x for x in tickers[market] if x["symbol"] != symbol]
    save_tickers(tickers)
    return jsonify({"ok": True})


# ── Портфолио ──────────────────────────────────────────────────────────────

@app.route("/api/portfolio", methods=["GET"])
def get_portfolio():
    return jsonify(load_portfolio())

@app.route("/api/portfolio", methods=["POST"])
def save_portfolio_route():
    save_portfolio(request.json)
    return jsonify({"ok": True})

@app.route("/api/portfolio/pnl")
def portfolio_pnl():
    """Изчислява P&L за всяка позиция."""
    portfolio = load_portfolio()
    if not portfolio:
        return jsonify([])

    symbols = list(portfolio.keys())
    try:
        data = yf.download(symbols if len(symbols) > 1 else symbols[0],
                           period="2d", interval="1d",
                           group_by="ticker", auto_adjust=True, progress=False)
    except:
        return jsonify([])

    results = []
    for sym, pos in portfolio.items():
        try:
            qty       = float(pos.get("qty", 0))
            avg_price = float(pos.get("avg_price", 0))

            if len(symbols) == 1:
                df = data
            else:
                df = data[sym]

            df = df.dropna()
            if df.empty:
                continue

            current = float(df.iloc[-1]["Close"])
            cost    = qty * avg_price
            value   = qty * current
            pnl     = value - cost
            pnl_pct = (pnl / cost * 100) if cost else 0

            results.append({
                "symbol":     sym,
                "name":       pos.get("name", sym),
                "qty":        qty,
                "avg_price":  avg_price,
                "current":    round(current, 2),
                "cost":       round(cost, 2),
                "value":      round(value, 2),
                "pnl":        round(pnl, 2),
                "pnl_pct":    round(pnl_pct, 2),
            })
        except:
            continue

    return jsonify(results)


@app.route("/api/export/csv")
def export_csv():
    """Генерира CSV с текущи данни."""
    all_items = get_all_symbols()
    symbols   = [x["symbol"] for x in all_items]
    name_map  = {x["symbol"]: x["name"] for x in all_items}
    market_map = {x["symbol"]: x["market"] for x in all_items}

    try:
        data = yf.download(symbols, period="2d", interval="1d",
                           group_by="ticker", auto_adjust=True, progress=False)
    except:
        return "Error", 500

    rows = ["Symbol,Name,Market,Price,Change%,Volume"]
    for sym in symbols:
        try:
            df = data[sym] if len(symbols) > 1 else data
            df = df.dropna()
            if df.empty or len(df) < 2:
                continue
            price  = round(float(df.iloc[-1]["Close"]), 2)
            prev   = round(float(df.iloc[-2]["Close"]), 2)
            chg    = round((price - prev) / prev * 100, 2)
            vol    = int(df.iloc[-1]["Volume"])
            rows.append(f'{sym},{name_map.get(sym, sym)},{market_map.get(sym,"")},{price},{chg},{vol}')
        except:
            continue

    from flask import Response
    return Response(
        "\n".join(rows),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment;filename=market_data.csv"}
    )


if __name__ == "__main__":
    print("\n🚀 MarketPulse стартира на http://localhost:5000\n")
    app.run(debug=True, port=5000)
